import Piscina from './index';

// Used as the require() entry point to maintain existing behavior
export = Piscina;
