const set = require('regenerate')();
set.addRange(0xD800, 0xDFFF);
exports.characters = set;
