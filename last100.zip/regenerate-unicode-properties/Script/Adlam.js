const set = require('regenerate')();
set.addRange(0x1E900, 0x1E94B).addRange(0x1E950, 0x1E959).addRange(0x1E95E, 0x1E95F);
exports.characters = set;
