const set = require('regenerate')();
set.addRange(0x102A0, 0x102D0);
exports.characters = set;
