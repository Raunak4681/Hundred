const set = require('regenerate')();
set.addRange(0x1F1E6, 0x1F1FF);
exports.characters = set;
