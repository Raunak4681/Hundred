declare const queueMicrotask: (cb: () => void) => void
export = queueMicrotask
