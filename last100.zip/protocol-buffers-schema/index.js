var parse = require('./parse')
var stringify = require('./stringify')

module.exports = parse
module.exports.parse = parse
module.exports.stringify = stringify
