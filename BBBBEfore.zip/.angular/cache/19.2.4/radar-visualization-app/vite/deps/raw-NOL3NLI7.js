import {
  BaseDecoder
} from "./chunk-JSOACJM5.js";
import "./chunk-4MWRP73S.js";

// node_modules/geotiff/dist-module/compression/raw.js
var RawDecoder = class extends BaseDecoder {
  decodeBlock(buffer) {
    return buffer;
  }
};
export {
  RawDecoder as default
};
//# sourceMappingURL=raw-NOL3NLI7.js.map
