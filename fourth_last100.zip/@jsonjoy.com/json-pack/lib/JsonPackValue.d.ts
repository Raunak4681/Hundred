export declare class JsonPackValue<T = Uint8Array> {
    readonly val: T;
    constructor(val: T);
}
