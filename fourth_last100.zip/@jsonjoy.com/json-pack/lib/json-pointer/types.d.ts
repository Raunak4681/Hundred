export type PathStep = string | number;
export type Path = readonly PathStep[];
