export type SymbolTable = string[];
