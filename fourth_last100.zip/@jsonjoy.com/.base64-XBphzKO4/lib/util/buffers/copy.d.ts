export declare const copy: <T extends Uint8Array>(arr: T) => T;
