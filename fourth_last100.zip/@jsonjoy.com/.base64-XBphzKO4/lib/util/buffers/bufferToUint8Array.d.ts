/// <reference types="node" />
export declare const bufferToUint8Array: (buf: Buffer) => Uint8Array;
