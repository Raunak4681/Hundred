export declare const createFromBase64Bin: (chars?: string, pad?: string) => (view: DataView, offset: number, length: number) => Uint8Array;
