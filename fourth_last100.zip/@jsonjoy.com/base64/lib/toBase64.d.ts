export declare const toBase64: (uint8: Uint8Array) => string;
