export declare const toBase64Bin: (uint8: Uint8Array, start: number, length: number, dest: DataView, offset: number) => number;
