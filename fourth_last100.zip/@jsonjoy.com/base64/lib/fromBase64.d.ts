export declare const fromBase64: (encoded: string) => Uint8Array;
