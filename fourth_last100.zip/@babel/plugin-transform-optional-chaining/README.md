# @babel/plugin-transform-optional-chaining

> Transform optional chaining operators into a series of nil checks

See our website [@babel/plugin-transform-optional-chaining](https://babeljs.io/docs/babel-plugin-transform-optional-chaining) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-optional-chaining
```

or using yarn:

```sh
yarn add @babel/plugin-transform-optional-chaining --dev
```
