// TODO: Remove in Babel 8

module.exports = require("core-js-compat/data.json");
