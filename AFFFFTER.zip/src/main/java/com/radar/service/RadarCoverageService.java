package com.radar.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Point;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.util.GeometricShapeFactory;
import java.util.ArrayList;
import java.util.List;

@Service
public class RadarCoverageService {
    private final TiffElevationService tiffElevationService;
    private final TerrainComplexityCalculator terrainComplexityCalculator;
    private final GeometryFactory geometryFactory;
    private final double EARTH_RADIUS = 6371000; // Earth's radius in meters

    @Autowired
    public RadarCoverageService(TiffElevationService tiffElevationService, TerrainComplexityCalculator terrainComplexityCalculator) {
        this.tiffElevationService = tiffElevationService;
        this.terrainComplexityCalculator = terrainComplexityCalculator;
        this.geometryFactory = new GeometryFactory();
    }

    public Geometry calculateRadarCoverage(double longitude, double latitude, double radarHeight, 
                                          double range, double tiltAngle) {
        if (!tiffElevationService.isWithinCoverage(longitude, latitude)) {
            throw new IllegalStateException("Radar location is outside elevation data coverage");
        }

        // Get radar base elevation
        double baseElevation = tiffElevationService.getElevation(longitude, latitude);
        double totalHeight = baseElevation + radarHeight;

        // Calculate terrain complexity to adjust coverage resolution
        double complexity = terrainComplexityCalculator.calculateTerrainComplexity(longitude, latitude, range);
        int numPoints = (int)(360 * (1 + complexity)); // Increase resolution in complex terrain
        
        // Create points for coverage area with terrain-aware resolution
        List<Coordinate> coordinates = new ArrayList<>();
        double angleStep = 360.0 / numPoints;
        double prevVisible = true;
        Coordinate prevCoord = null;

        for (int i = 0; i <= numPoints; i++) {
            double angle = Math.toRadians(i * angleStep);
            // Use multiple range checks to create irregular shape
            for (double r = range; r >= 0; r -= range/10) {
                double dx = r * Math.cos(angle);
                double dy = r * Math.sin(angle);
                
                double pointLon = longitude + (dx / (111320 * Math.cos(Math.toRadians(latitude))));
                double pointLat = latitude + (dy / 110540);

                if (tiffElevationService.isWithinCoverage(pointLon, pointLat)) {
                    double pointElevation = tiffElevationService.getElevation(pointLon, pointLat);
                    
                    boolean isVisible = isPointVisible(longitude, latitude, totalHeight, 
                                     pointLon, pointLat, pointElevation, 
                                     tiltAngle);

                    // Add point if it's the first visible point at this angle
                    if (isVisible) {
                        Coordinate coord = new Coordinate(pointLon, pointLat);
                        if (!prevVisible && prevCoord != null) {
                            // Add intermediate point for smoother transition
                            coordinates.add(prevCoord);
                        }
                        coordinates.add(coord);
                        // Add smoothing points in complex terrain areas
                        if (complexity > 0.5 && prevCoord != null) {
                            terrainComplexityCalculator.addSmoothingPoints(
                                coordinates, prevCoord, coord,
                                longitude, latitude, totalHeight, tiltAngle
                            );
                        }
                        break;
                    } else {
                        prevCoord = new Coordinate(pointLon, pointLat);
                    }
                    prevVisible = isVisible;
                }
            }
        }

        // Close the polygon
        if (!coordinates.isEmpty()) {
            coordinates.add(coordinates.get(0));
        }

        // Create coverage polygon
        return geometryFactory.createPolygon(coordinates.toArray(new Coordinate[0]));
    }

    private boolean isPointVisible(double radarLon, double radarLat, double radarHeight,
                                 double pointLon, double pointLat, double pointElevation,
                                 double tiltAngle) {
        // Calculate distance between radar and point
        double distance = calculateDistance(radarLon, radarLat, pointLon, pointLat);
        
        // Calculate expected height at this distance considering tilt angle
        double expectedHeight = radarHeight - (distance * Math.tan(Math.toRadians(tiltAngle)));
        
        // Account for Earth's curvature
        double earthCurvature = (distance * distance) / (2 * EARTH_RADIUS);
        expectedHeight -= earthCurvature;

        // Check if terrain elevation is below the radar coverage
        return pointElevation <= expectedHeight;
    }

    private double calculateDistance(double lon1, double lat1, double lon2, double lat2) {
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                   Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                   Math.sin(dLon/2) * Math.sin(dLon/2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return EARTH_RADIUS * c;
    }
}