package com.radar.service;

import com.radar.repository.ElevationDataRepository;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.WKTReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TerrainService {
    private final ElevationDataRepository elevationDataRepository;
    private final WKTReader wktReader;

    @Autowired
    public TerrainService(ElevationDataRepository elevationDataRepository) {
        this.elevationDataRepository = elevationDataRepository;
        this.wktReader = new WKTReader();
    }

    @Transactional(readOnly = true)
    public Double getElevationAtPoint(double longitude, double latitude) {
        return elevationDataRepository.getElevationAtPoint(longitude, latitude);
    }

    @Transactional(readOnly = true)
    public Geometry calculateTerrainAwareRadarCoverage(double longitude, double latitude, double range) {
        try {
            // Get elevation at radar location
            Double radarElevation = getElevationAtPoint(longitude, latitude);
            if (radarElevation == null) {
                throw new RuntimeException("Could not determine radar elevation");
            }

            // Calculate terrain-aware coverage
            String wktCoverage = elevationDataRepository.getTerrainAwareRadarCoverage(longitude, latitude, range);
            if (wktCoverage == null || wktCoverage.isEmpty()) {
                throw new RuntimeException("No coverage area calculated");
            }

            return wktReader.read(wktCoverage);
        } catch (Exception e) {
            throw new RuntimeException("Error calculating terrain-aware radar coverage: " + e.getMessage(), e);
        }
    }
}