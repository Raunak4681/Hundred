import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as L from 'leaflet';

@Component({
  selector: 'app-radar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './radar.component.html',
  styles: [`
    .radar-container {
      padding: 20px;
      height: 100vh;
    }
    h2 {
      color: var(--gray-900);
      margin-bottom: 20px;
    }
    #radar-map {
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
  `]
})
export class RadarComponent implements OnInit {
  private map!: L.Map;
  private radarCircle!: L.Circle;

  ngOnInit() {
    this.initializeMap();
    this.addRadarCoverage();
  }

  private initializeMap() {
    this.map = L.map('radar-map').setView([51.505, -0.09], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(this.map);
  }

  private addRadarCoverage() {
    this.radarCircle = L.circle([51.505, -0.09], {
      color: 'red',
      fillColor: '#f03',
      fillOpacity: 0.2,
      radius: 2000 // 2km radius
    }).addTo(this.map);
  }
}